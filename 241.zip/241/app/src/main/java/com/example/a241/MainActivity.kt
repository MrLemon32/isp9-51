package com.example.a241

import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private val trackList = arrayOf(
        R.raw.audio,
        R.raw.dog,

    )
    private var currentTrackIndex = 0

    private lateinit var mediaPlayer: MediaPlayer
    private var isPaused = false
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var runnable: Runnable


    private lateinit var btnPrev: Button
    private lateinit var btnPlay: Button
    private lateinit var btnNext: Button
    private lateinit var btnPause: Button
    private lateinit var btnStop: Button
    private lateinit var seekBar: SeekBar
    private lateinit var tvCurrentTime: TextView
    private lateinit var tvTotalTime: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupListeners()
    }

    private fun initViews() {
        btnPrev = findViewById(R.id.btnPrev)
        btnPlay = findViewById(R.id.btnPlay)
        btnNext = findViewById(R.id.btnNext)
        btnPause = findViewById(R.id.btnPause)
        btnStop = findViewById(R.id.btnStop)
        seekBar = findViewById(R.id.seekBar)
        tvCurrentTime = findViewById(R.id.tvCurrentTime)
        tvTotalTime = findViewById(R.id.tvTotalTime)
    }

    private fun setupListeners() {
        btnPlay.setOnClickListener {
            if (::mediaPlayer.isInitialized && isPaused) {

                mediaPlayer.start()
                isPaused = false
                updateButtonState(true)
                Toast.makeText(this, "Play resumed", Toast.LENGTH_SHORT).show()
            } else {

                playTrack(currentTrackIndex)
            }
        }

        btnPause.setOnClickListener {
            if (::mediaPlayer.isInitialized && mediaPlayer.isPlaying) {
                mediaPlayer.pause()
                isPaused = true
                updateButtonState(false)
                Toast.makeText(this, "Paused", Toast.LENGTH_SHORT).show()
            }
        }

        btnStop.setOnClickListener {
            if (::mediaPlayer.isInitialized) {
                mediaPlayer.stop()
                mediaPlayer.reset()
                mediaPlayer.release()
                isPaused = false
                updateButtonState(null)
                seekBar.progress = 0
                tvCurrentTime.text = "00:00"
                handler.removeCallbacks(runnable)
                Toast.makeText(this, "Stopped", Toast.LENGTH_SHORT).show()
            }
        }

        btnPrev.setOnClickListener {
            if (trackList.isNotEmpty()) {
                currentTrackIndex = (currentTrackIndex - 1 + trackList.size) % trackList.size
                playTrack(currentTrackIndex)
            }
        }

        btnNext.setOnClickListener {
            if (trackList.isNotEmpty()) {
                currentTrackIndex = (currentTrackIndex + 1) % trackList.size
                playTrack(currentTrackIndex)
            }
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser && ::mediaPlayer.isInitialized) {
                    mediaPlayer.seekTo(progress)
                    tvCurrentTime.text = formatTime(progress)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun playTrack(index: Int) {

        if (::mediaPlayer.isInitialized) {
            mediaPlayer.release()
        }

        mediaPlayer = MediaPlayer.create(this, trackList[index])
        mediaPlayer.start()
        isPaused = false
        updateButtonState(true)


        seekBar.max = mediaPlayer.duration
        tvTotalTime.text = formatTime(mediaPlayer.duration)


        runnable = object : Runnable {
            override fun run() {
                if (::mediaPlayer.isInitialized && mediaPlayer.isPlaying) {
                    val currentPos = mediaPlayer.currentPosition
                    seekBar.progress = currentPos
                    tvCurrentTime.text = formatTime(currentPos)
                }
                handler.postDelayed(this, 100)
            }
        }
        handler.post(runnable)


        mediaPlayer.setOnCompletionListener {
            currentTrackIndex = (currentTrackIndex + 1) % trackList.size
            playTrack(currentTrackIndex)
        }

        Toast.makeText(this, "Playing track ${index + 1}", Toast.LENGTH_SHORT).show()
    }

    private fun updateButtonState(isPlaying: Boolean?) {
        when (isPlaying) {
            true -> {
                btnPlay.isEnabled = false
                btnPause.isEnabled = true
                btnStop.isEnabled = true
                btnPrev.isEnabled = true
                btnNext.isEnabled = true
            }
            false -> {
                btnPlay.isEnabled = true
                btnPause.isEnabled = false
                btnStop.isEnabled = true
                btnPrev.isEnabled = true
                btnNext.isEnabled = true
            }
            null -> {
                btnPlay.isEnabled = true
                btnPause.isEnabled = false
                btnStop.isEnabled = false
                btnPrev.isEnabled = true
                btnNext.isEnabled = true
                seekBar.progress = 0
            }
        }
    }

    private fun formatTime(ms: Int): String {
        val minutes = TimeUnit.MILLISECONDS.toMinutes(ms.toLong())
        val seconds = TimeUnit.MILLISECONDS.toSeconds(ms.toLong()) - minutes * 60
        return String.format("%02d:%02d", minutes, seconds)
    }

    override fun onStop() {
        super.onStop()

        if (::mediaPlayer.isInitialized && mediaPlayer.isPlaying) {
            mediaPlayer.pause()
            isPaused = true
            updateButtonState(false)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(runnable)
        if (::mediaPlayer.isInitialized) {
            mediaPlayer.release()
        }
    }
}